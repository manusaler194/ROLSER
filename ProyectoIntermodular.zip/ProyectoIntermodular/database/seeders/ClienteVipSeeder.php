<?php

namespace Database\Seeders;

use App\Models\Articulo;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;
use Faker\Factory as Faker;

class ClienteVipSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $faker = Faker::create('es_ES');

        DB::table('clientes_vip')->insert([
            'nombre' => 'VIP de Prueba',
            'telefono' => '644444444',
            'email' => 'vip@gmail.com',
            'password' => Hash::make('12345678'),
            'direccion' => 'Avenida del Lujo 777, Valencia',
            'created_at' => now(),
            'updated_at' => now(),
            'id_administrador' => 1, 
            'id_catalogo' => 1,      
            'id_comercial' => 1,     
        ]);

        for ($i = 1; $i < 11; $i++) {
            DB::table('clientes_vip')->insert([

                'nombre' => $faker->name(),
                'telefono' => $faker->phoneNumber(),
                'email' => $faker->unique()->email(),
                'password' => Hash::make('password'),
                'direccion' => $faker->address(),
                'created_at' => $faker->date(),
                'updated_at' => $faker->date(),
                'id_administrador' => rand(1,10),
                'id_catalogo' => rand(1,10),
                'id_comercial' => rand(1,10),
            ]);
        }
    }
}
