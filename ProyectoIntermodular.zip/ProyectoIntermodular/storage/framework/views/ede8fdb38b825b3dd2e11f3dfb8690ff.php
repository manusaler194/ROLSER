<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Artículos</title>
</head>
<body>

<?php $__empty_1 = true; $__currentLoopData = $resultado; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <h3><?php echo e($dato->titulo); ?></h3>
    <p><?php echo e($dato->descripcion); ?></p>
    <hr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <h2>No hay nada</h2>
<?php endif; ?>

<?php echo $resultado->links(); ?>


</body>
</html>
<?php /**PATH /var/www/html/resources/views/articulos.blade.php ENDPATH**/ ?>