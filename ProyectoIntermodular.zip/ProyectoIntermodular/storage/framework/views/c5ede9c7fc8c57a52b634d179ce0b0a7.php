<?php $__empty_1 = true; $__currentLoopData = $datos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
<li>
<?php echo e($item->nombre); ?> <?php echo e($item->descripcion); ?>


     <a href="<?php echo e(route('editar', $item->id)); ?>" >Edit</a> <!--añadimos también EDITAR-->
 <form action="<?php echo e(route('borrar', $item->id)); ?>" method="post"> <!--añadimos también BORRAR-->
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <button type="submit">borrar</button>
    </form>
</li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
   <li>NO HAY NADA </li>
<?php endif; ?>
<?php /**PATH /var/www/html/resources/views/index.blade.php ENDPATH**/ ?>