<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>

<?php dump($categorias->toArray()); ?>

<form method="post" action="<?php echo e(route('mostrar')); ?>">
    <?php echo csrf_field(); ?>


<select name="categoria" id="categoria">

<?php $__empty_1 = true; $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
  <option value=" <?php echo e($categoria->id); ?>"> <?php echo e($categoria->nombre); ?></option>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
  No hay informacion
  <?php endif; ?>
</select>
<input type="submit" value="Enviar" name="Enviar">
</form>
</body>
</html>
<?php /**PATH /var/www/html/resources/views/ejercicio.blade.php ENDPATH**/ ?>