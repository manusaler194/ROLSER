
<form method="post" action="<?php echo e(route('almacenar')); ?>">

        
        <?php echo csrf_field(); ?>
        <label for="name">Nombre:</label>
        <input type="text" name="nombre" value="<?php echo e(old('nombre')); ?>"/>
        <!--ponemos old porque en el caso que carguemos el formulario y diera error habría que volver a introducir todos los campos, así recuerda o guarda los campos que están bien-->
     <?php echo $errors->first('nombre', '<small>:message</small><br>' ); ?>  <!-- así especificamos los errores debajo-->

        <label for="price">Descripcion:</label>
        <input type="text" name="descripcion" value="<?php echo e(old('descripcion')); ?>"/>
     <?php echo $errors->first('descripcion', '<small>:message</small><br>' ); ?>



    <button type="submit">Crear</button>
</form>

<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

    <script>
    <?php if(session('mensaje')): ?>
    swal("Buen Trabajo!", "<?php echo e(session('mensaje')); ?>", "success");
    <?php endif; ?>
    </script>
<?php /**PATH /var/www/html/resources/views/insertar.blade.php ENDPATH**/ ?>