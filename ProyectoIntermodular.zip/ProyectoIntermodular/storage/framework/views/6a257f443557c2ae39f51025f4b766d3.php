<form method="post" action="<?php echo e(route('actualizar', $dato)); ?>">

          <div>
              <?php echo method_field('PATCH'); ?>
              <?php echo csrf_field(); ?>

              <label for="name">nombre:</label>
              <input type="text"  name="nombre" value="<?php echo e($dato->nombre); ?>"/>
          </div>
          <div >
              <label for="descripcion">descripcion</label>
              <input type="text"  name="descripcion" value="<?php echo e($dato->descripcion); ?>"/>
          </div>

          <button type="submit" >Actualizar</button>
      </form>
  </div>
</div>
<?php /**PATH /var/www/html/resources/views/editar.blade.php ENDPATH**/ ?>